(() => {
  'use strict';

  const configKey = 'shanghai-flashcards-v1';
  const byId = (id) => document.getElementById(id);
  const tabs = byId('lesson-list');
  const select = byId('lesson-select');
  const cards = byId('cards');
  const voice = byId('voice');
  const status = byId('audio-status');
  const buttons = Array.from(document.querySelectorAll('[data-accent], [data-style]'));
  const speaker = '<svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H3v6h3l5 4V5z"/><path d="M15 9a4 4 0 0 1 0 6m3-9a8 8 0 0 1 0 12"/></svg>';
  const colors = [['#ffedc1', '#bc760b'], ['#e3edff', '#5169bf'], ['#e9e1ff', '#8750ae'], ['#ffe4ed', '#b65577'], ['#dff2dc', '#448858']];
  const saved = readSettings();
  let lessonIndex = Number.isInteger(saved.lesson) && window.lessons[saved.lesson] ? saved.lesson : 1;
  let accent = saved.accent === 'us' ? 'us' : 'uk';
  let style = saved.style === 'comic' ? 'comic' : 'cute';
  let hidden = false;
  let activeCard = null;
  let playback = 0;

  function readSettings() {
    try { return JSON.parse(localStorage.getItem(configKey)) || {}; }
    catch { return {}; }
  }

  function saveSettings() {
    try { localStorage.setItem(configKey, JSON.stringify({lesson: lessonIndex, accent, style})); }
    catch { /* 微信隐私设置禁用存储时仍可学习。 */ }
  }

  function make(tag, className, value) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (value !== undefined) node.textContent = value;
    return node;
  }

  function image(key, className) {
    const node = make('img', className);
    node.alt = '';
    node.decoding = 'async';
    node.dataset.image = key;
    node.src = 'assets/' + style + '/' + key + '.png';
    return node;
  }

  function clearPlaying() {
    if (activeCard) activeCard.classList.remove('playing');
    activeCard = null;
  }

  function stop() {
    playback += 1;
    voice.onended = null;
    voice.onerror = null;
    voice.pause();
    clearPlaying();
    status.hidden = true;
  }

  function speak(card, word) {
    stop();
    const current = playback;
    const filename = word.toLowerCase().replace(/[^a-z ]/g, '').trim().replace(/ +/g, '-');
    const onFailure = () => {
      if (current !== playback) return;
      clearPlaying();
      status.textContent = '发音没加载成功，请检查网络后再点一次。';
      status.hidden = false;
    };
    activeCard = card;
    card.classList.add('playing');
    voice.onended = () => {
      if (current === playback) clearPlaying();
    };
    voice.onerror = onFailure;
    voice.src = 'assets/audio/' + accent + '/' + filename + '.mp3';
    // Keep play() in the tap handler so WeChat and Safari accept the gesture.
    const result = voice.play();
    if (result && result.catch) result.catch(onFailure);
  }

  function renderCard([word, meaning, images], index) {
    const node = make('button', 'card');
    node.type = 'button';
    const keys = images.split(' ');
    const art = make('span', keys.length > 1 ? 'card-art duo' : 'card-art');
    art.setAttribute('aria-hidden', 'true');
    const [tint, spark] = colors[index % colors.length];
    node.style.setProperty('--tint', tint);
    node.style.setProperty('--spark', spark);
    keys.forEach((key) => art.appendChild(image(key)));
    const copy = make('span', 'card-copy');
    const english = make('span', 'word', word);
    english.lang = 'en';
    const icon = make('span', 'speaker');
    icon.setAttribute('aria-hidden', 'true');
    icon.innerHTML = speaker;
    copy.append(english, make('span', 'meaning', meaning), icon);
    node.append(art, copy);
    node.addEventListener('click', () => speak(node, word));
    return node;
  }

  function updateSettings() {
    document.documentElement.dataset.art = style;
    buttons.forEach((button) => {
      button.setAttribute('aria-pressed', String(
        button.dataset.accent === accent || button.dataset.style === style
      ));
    });
  }

  function chooseLesson(index) {
    stop();
    lessonIndex = index;
    const [label, title, english, page, , words] = window.lessons[lessonIndex];
    byId('lesson-number').textContent = label;
    byId('lesson-title').textContent = title;
    byId('lesson-english').textContent = english;
    byId('lesson-count').textContent = words.length + ' 张卡片';
    byId('textbook-link').href = 'https://zhiquai.github.io/shanghai-english-reader/#' + page;
    byId('previous').disabled = index === 0;
    byId('next').disabled = index === window.lessons.length - 1;
    select.value = String(index);
    Array.from(tabs.children).forEach((tab, i) => {
      if (i === index) tab.setAttribute('aria-current', 'true');
      else tab.removeAttribute('aria-current');
    });
    cards.textContent = '';
    words.forEach((word, i) => cards.appendChild(renderCard(word, i)));
    saveSettings();
  }

  window.lessons.forEach(([label, title, , , icon], index) => {
    const button = make('button', 'unit');
    button.type = 'button';
    button.append(image(icon, 'unit-icon'), make('span', 'unit-name', title), make('span', 'unit-tag', label));
    button.addEventListener('click', () => chooseLesson(index));
    tabs.appendChild(button);
    const option = make('option', '', label + ' · ' + title);
    option.value = String(index);
    select.appendChild(option);
  });

  select.addEventListener('change', () => chooseLesson(Number(select.value)));
  buttons.forEach((button) => button.addEventListener('click', () => {
    if (button.dataset.accent && button.dataset.accent !== accent) {
      stop();
      accent = button.dataset.accent;
    }
    if (button.dataset.style && button.dataset.style !== style) {
      style = button.dataset.style;
      document.querySelectorAll('[data-image]').forEach((node) => {
        node.src = 'assets/' + style + '/' + node.dataset.image + '.png';
      });
    }
    updateSettings();
    saveSettings();
  }));

  const recall = byId('recall');
  recall.addEventListener('click', () => {
    hidden = !hidden;
    cards.classList.toggle('masked', hidden);
    recall.setAttribute('aria-pressed', String(hidden));
    recall.textContent = hidden ? '显示中文' : '隐藏中文';
  });

  function move(offset) {
    chooseLesson(lessonIndex + offset);
    byId('lesson-title').scrollIntoView({block: 'center'});
  }
  byId('previous').addEventListener('click', () => move(-1));
  byId('next').addEventListener('click', () => move(1));
  updateSettings();
  chooseLesson(lessonIndex);
})();
